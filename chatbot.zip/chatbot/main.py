from flask import Flask, request, render_template, jsonify
from openai import OpenAI
from dotenv import load_dotenv
import os
from prompt import generate_skillpath_prompt

# Load environment variables
load_dotenv()

# Initialize Hugging Face client
client = OpenAI(
    base_url="https://router.huggingface.co/v1",
    api_key=os.environ.get("HF_TOKEN")
)
model = "meta-llama/Llama-3.1-8B-Instruct:fireworks-ai"

# Initialize Flask
app = Flask(__name__)

# Frontend route
@app.route("/")
def index():
    return render_template("index.html")

# Backend API route to handle AI requests
@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    career = data.get("career", "").strip()  # Get career from frontend

    # Generate the AI prompt
    prompt = generate_skillpath_prompt(career)

    try:
        # Call Hugging Face / OpenAI router
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        answer = response.choices[0].message.content
    except Exception as e:
        answer = f"Error: {str(e)}"

    # Return AI response to frontend
    return jsonify({"response": answer})

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
