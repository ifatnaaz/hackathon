def generate_skillpath_prompt(career):
    return f"""
The user wants to become a {career}.
Your tasks:

Skills Required:
- List all key skills needed for this career.

Roadmap:
- Create a detailed roadmap to acquire these skills from scratch.

Weekly Plan:
- Provide a weekly plan to efficiently learn these skills.

Resources:
- Suggest free and paid resources (Coursera, YouTube, Udemy, etc.) for each skill.

Projects:
- Suggest projects or real-world experiences to practice the skills.

Output in a friendly, mentor-like tone.
Use bullet points, emojis, and short paragraphs to make it engaging and actionable.
"""
