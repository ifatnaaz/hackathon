let XP = 0, level = 1;
let conversationStage = 0;
let collectedData = {
  topic: null,
  skill_level: null,
  goal: null
};

async function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;
  addBubble(message, "user");
  input.value = "";

  if (conversationStage === 0) {
    collectedData.topic = message;
    addBubble("Got it! What’s your current skill level — Beginner, Intermediate, or Advanced?", "ai");
    conversationStage = 1;
    return;
  }

  if (conversationStage === 1) {
    collectedData.skill_level = message;
    addBubble("Cool 😎 And what’s your ultimate goal with this skill? (e.g., Get a job, build a project, etc.)", "ai");
    conversationStage = 2;
    return;
  }

  if (conversationStage === 2) {
    collectedData.goal = message;
    addBubble("Awesome! Let’s generate your personalized roadmap... 🚀", "ai");
    conversationStage = 3;
    await fetchRoadmap();
  } else {
    // Once roadmap is generated, continue normal chat
    await fetchFollowup(message);
  }
}

function addBubble(text, from) {
  const chatbox = document.getElementById("chatbox");
  const div = document.createElement("div");
  div.className = from;
  div.innerText = text;
  chatbox.appendChild(div);
  chatbox.scrollTop = chatbox.scrollHeight;
}

async function fetchRoadmap() {
  const response = await fetch("/get_roadmap", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: `Topic: ${collectedData.topic}, Level: ${collectedData.skill_level}, Goal: ${collectedData.goal}`
    }),
  });

  let data;
  try {
    data = await response.json();
  } catch (err) {
    addBubble("⚠️ Couldn't parse roadmap data.", "ai");
    return;
  }

  if (data.error) {
    addBubble("❌ Error: " + data.error, "ai");
    return;
  }

  addBubble("Here’s your personalized SkillPath! 🌟", "ai");
  renderDashboard(data);
  addBubble("Would you like me to suggest some real courses or GitHub projects next? 👩‍💻", "ai");
  conversationStage = 4;
}

async function fetchFollowup(message) {
  // Optionally: send additional questions to backend
  addBubble("Okay, let me process that... 🔍", "ai");
}

function renderDashboard(data) {
  const roadmap = data.roadmap || [];
  const planDiv = document.getElementById("weekly-plan");
  const projectsDiv = document.getElementById("projects");

  // Weekly Plan
  planDiv.innerHTML = "<h3>🗓 Weekly Plan</h3>";
  data.weekly_plan?.forEach(day => {
    planDiv.innerHTML += `<p><strong>${day.day}:</strong> ${day.tasks.join(", ")}</p>`;
  });

  // Projects
  projectsDiv.innerHTML = "<h3>🏆 Projects</h3>";
  data.projects?.forEach(p => {
    projectsDiv.innerHTML += `<p><strong>${p.title}</strong> — ${p.desc}</p>`;
  });

  // Chart.js - Skill Progress
  const ctx = document.getElementById("skillChart").getContext("2d");
  const skillNames = roadmap.map(s => s.skill);
  const skillProgress = roadmap.map(s => s.progress);

  new Chart(ctx, {
    type: "bar",
    data: {
      labels: skillNames,
      datasets: [{
        label: "Progress %",
        data: skillProgress,
        backgroundColor: ["#ffb703", "#219ebc", "#8ecae6"]
      }]
    },
    options: {
      responsive: true,
      animation: { duration: 1500 },
      scales: { y: { beginAtZero: true, max: 100 } }
    }
  });

  // XP / Level logic
  XP = roadmap.reduce((acc, s) => acc + (s.progress / 10), XP);
  if (XP > level * 10) level++;
  document.getElementById("xpDisplay").innerText = `XP 🌟: ${Math.floor(XP)} | Level: ${level}`;

  // Mermaid Mindmap
  let diagram = "graph TD;\nA[Start]";
  roadmap.forEach(s => {
    const skillNode = s.skill.replace(/\s+/g, "_");
    diagram += `-->${skillNode}[${s.skill}]`;
  });
  document.getElementById("mindmap").innerHTML = diagram;
  mermaid.init();
}

function exportDashboard() {
  html2canvas(document.querySelector(".dashboard")).then(canvas => {
    const link = document.createElement("a");
    link.download = "SkillPath_Dashboard.png";
    link.href = canvas.toDataURL();
    link.click();
  });
}
