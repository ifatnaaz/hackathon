const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Load skills and resources
const skills = JSON.parse(fs.readFileSync("skills.json", "utf8"));
const resources = JSON.parse(fs.readFileSync("resources.json", "utf8"));

// Route to get all careers
app.get("/careers", (req, res) => {
  res.json(Object.keys(skills));
});

// Route to analyze user skills
app.post("/analyze", (req, res) => {
  const { career, userSkills } = req.body;
  const required = skills[career] || [];
  
  const matched = required.filter(skill => userSkills.includes(skill));
  const missing = required.filter(skill => !userSkills.includes(skill));
  const percentMatch = Math.round((matched.length / required.length) * 100);

  // Recommended resources for missing skills
  const recommendations = missing.map(skill => ({
    skill,
    links: resources[skill] || []
  }));

  res.json({ career, required, matched, missing, percentMatch, recommendations });
});

// Start server
app.listen(5000, () => console.log("✅ Backend running on http://localhost:5000"));
