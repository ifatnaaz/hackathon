let ageSelected = null;
let inputSelected = null;

// Age selection
function setAge(age) {
    ageSelected = age;
    document.getElementById('age').value = age;
}

// Input method selection
function setInput(input) {
    inputSelected = input;
    document.getElementById('inputMethod').value = input;
}

// Voice recognition
function startVoice(fieldId) {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.start();
    recognition.onresult = function(event) {
        const text = event.results[0][0].transcript;
        document.getElementById(fieldId).value = text;
    };
    recognition.onerror = function() {
        alert('Voice input failed. Please type or tap letters instead.');
    };
}

// Drawing canvas setup for touch + mouse
const canvas = document.getElementById('drawingCanvas');
const ctx = canvas.getContext('2d');
let drawing = false;

function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    if (e.touches) {
        return {
            x: e.touches[0].clientX - rect.left,
            y: e.touches[0].clientY - rect.top
        };
    } else {
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }
}

function startDraw(e) {
    drawing = true;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    e.preventDefault();
}

function drawMove(e) {
    if (!drawing) return;
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = '#ff6f61';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    e.preventDefault();
}

function endDraw(e) {
    drawing = false;
    ctx.beginPath();
    e.preventDefault();
}

canvas.addEventListener('mousedown', startDraw);
canvas.addEventListener('mousemove', drawMove);
canvas.addEventListener('mouseup', endDraw);
canvas.addEventListener('mouseout', endDraw);

canvas.addEventListener('touchstart', startDraw);
canvas.addEventListener('touchmove', drawMove);
canvas.addEventListener('touchend', endDraw);

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Form submission
const form = document.getElementById('setupForm');
const output = document.getElementById('output');

form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value || 'Anonymous';
    const age = document.getElementById('age').value || 'N/A';
    const inputMethod = document.getElementById('inputMethod').value || 'N/A';
    const goals = document.getElementById('goals').value || 'N/A';

    const drawingData = canvas.toDataURL();

    output.style.display = 'block';
    output.innerHTML = `
        <h3>Welcome, ${name}! 🌟</h3>
        <p><strong>Age:</strong> ${age}</p>
        <p><strong>Preferred Input:</strong> ${inputMethod}</p>
        <p><strong>Your Interests:</strong> ${goals}</p>
        <p><strong>Your Drawing:</strong></p>
        <img src="${drawingData}" alt="Your Drawing" style="max-width:100%; border:1px solid #ff6f61; border-radius:10px;">
        <p>You're all set! Let's start your skill journey 🚀</p>
    `;

    form.reset();
    clearCanvas();
    ageSelected = null;
    inputSelected = null;
});
